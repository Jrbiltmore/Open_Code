
// Logic for managing Care to Remember profiles
let rememberMembers = [];

function getRememberMembers() {
    return rememberMembers;
}

function addMember(user) {
    if (!rememberMembers.includes(user)) {
        rememberMembers.push(user);
    }
}

function removeMember(user) {
    rememberMembers = rememberMembers.filter(member => member !== user);
}

module.exports = { getRememberMembers, addMember, removeMember };
