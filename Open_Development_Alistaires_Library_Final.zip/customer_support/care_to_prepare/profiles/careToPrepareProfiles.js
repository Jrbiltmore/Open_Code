
// Logic for managing Care to Prepare profiles
let prepareMembers = [];

function getPrepareMembers() {
    return prepareMembers;
}

function addMember(user) {
    if (!prepareMembers.includes(user)) {
        prepareMembers.push(user);
    }
}

function removeMember(user) {
    prepareMembers = prepareMembers.filter(member => member !== user);
}

module.exports = { getPrepareMembers, addMember, removeMember };
