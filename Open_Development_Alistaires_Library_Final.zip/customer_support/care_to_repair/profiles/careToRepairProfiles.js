
// Logic for managing Care to Repair profiles
let repairMembers = [];

function getRepairMembers() {
    return repairMembers;
}

function addMember(user) {
    if (!repairMembers.includes(user)) {
        repairMembers.push(user);
    }
}

function removeMember(user) {
    repairMembers = repairMembers.filter(member => member !== user);
}

module.exports = { getRepairMembers, addMember, removeMember };
