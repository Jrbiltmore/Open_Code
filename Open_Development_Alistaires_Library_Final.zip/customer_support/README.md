# Customer Support Project

This project handles customer support for the platform.