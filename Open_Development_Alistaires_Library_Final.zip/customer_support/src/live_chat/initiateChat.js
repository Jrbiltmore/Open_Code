
// Logic to initiate live chat with a random engager, with escalation to admin and developer
const engagers = ['engager1@example.com', 'engager2@example.com', 'engager3@example.com']; // List of engager emails
const admins = ['admin1@example.com', 'admin2@example.com', 'admin3@example.com']; // List of admin emails
const developers = ['dev1@example.com', 'dev2@example.com', 'dev3@example.com']; // List of developer emails

function getRandomUser(userList) {
    const randomIndex = Math.floor(Math.random() * userList.length);
    return userList[randomIndex];
}

function initiateChat(user, issueType) {
    let contact;
    if (issueType === 'tech_support') {
        contact = getRandomUser(developers);
    } else {
        contact = getRandomUser(engagers);
    }
    console.log(`Connecting ${user} with ${contact}`);
    // Logic to initiate chat between user and selected contact
    return contact;
}

function escalateChat(user, currentContact) {
    let newContact;
    if (engagers.includes(currentContact)) {
        newContact = getRandomUser(admins);
    } else if (admins.includes(currentContact)) {
        newContact = getRandomUser(developers);
    }
    console.log(`Escalating chat for ${user} from ${currentContact} to ${newContact}`);
    // Logic to escalate chat to new contact
    return newContact;
}

module.exports = { initiateChat, escalateChat };
