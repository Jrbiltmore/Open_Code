#!/bin/bash
# Script to run customer support