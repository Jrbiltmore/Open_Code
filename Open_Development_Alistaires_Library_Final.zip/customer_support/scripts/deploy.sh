#!/bin/bash
# Deployment script for customer support