#!/bin/bash
# Deployment script for marketing