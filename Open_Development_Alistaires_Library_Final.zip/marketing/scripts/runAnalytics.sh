#!/bin/bash
# Script to run marketing analytics