# Marketing Project

This project handles marketing for the platform.