#!/bin/bash
# Script to run experiments