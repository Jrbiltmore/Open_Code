#!/bin/bash
# Deployment script for R&D