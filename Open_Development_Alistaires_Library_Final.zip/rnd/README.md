# R&D Project

This project handles research and development for the platform.