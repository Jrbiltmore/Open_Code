#!/bin/bash
# Script to run training and documentation