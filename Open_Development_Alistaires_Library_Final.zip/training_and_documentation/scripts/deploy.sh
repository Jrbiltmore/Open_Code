#!/bin/bash
# Deployment script for training and documentation